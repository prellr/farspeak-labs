FARSPEAK LABS — LOGO PACK
=========================
Wordmark concept: "Transmission" (#02) is the locked primary identity.
"Terminal" (#03) is the alternate/dev-flavored mark.

No pictorial logo by design — wordmark-first.

------------------------------------------------------------
WHICH FILE DO I USE?
------------------------------------------------------------
• Prefer the .svg files for anything digital or print — they scale
  infinitely, stay crisp, and the colors/text are editable.
• Use the "-light" files on LIGHT backgrounds (dark ink).
  Use the non-light files on DARK backgrounds (light ink).
• "-crop" PNGs are tightly cropped (minimal padding) for embedding.
• The non-crop PNGs sit on a full background canvas (2400x1260, 2x).
• The animated GIF is for screens only (email, slides, social).

------------------------------------------------------------
CONTENTS
------------------------------------------------------------
02-transmission/   (PRIMARY)
  farspeak-02-transmission.svg            dark bg · vector · primary
  farspeak-02-transmission-light.svg      light bg · vector
  farspeak-02-transmission.png            dark bg · raster (2x)
  farspeak-02-transmission-light.png      light bg · raster (2x)
  farspeak-02-transmission-crop-dark.png  dark bg · tight crop
  farspeak-02-transmission-crop-light.png light bg · tight crop

03-terminal/   (ALTERNATE)
  farspeak-03-terminal.svg                dark bg · vector
  farspeak-03-terminal-light.svg          light bg · vector
  farspeak-03-terminal.png                dark bg · raster (2x)
  farspeak-03-terminal-light.png          light bg · raster (2x)
  farspeak-03-terminal-crop-dark.png      dark bg · tight crop
  farspeak-03-terminal-crop-light.png     light bg · tight crop
  farspeak-03-terminal-animated.gif       animated (typing + blinking cursor)

------------------------------------------------------------
BRAND TOKENS
------------------------------------------------------------
Background (dark)   #0A0A0B
Paper (light)       #F4F4F5
Signal (cyan)       #4CC2FF   ← Farspeak accent
Violet              #7C6CFF   ← reserved for 2nd product
Muted ink           #9A9AA3

Type:
  Display / wordmark  — Space Grotesk
  Mono / "LABS" label — JetBrains Mono
  Body                — Geist

Contact: team@farspeaklabs.com · farspeaklabs.com
